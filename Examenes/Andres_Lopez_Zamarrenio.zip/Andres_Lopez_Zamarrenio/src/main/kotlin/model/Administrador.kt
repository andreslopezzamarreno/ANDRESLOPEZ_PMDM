package model

class Administrador(private var id: Int, private var nombre: String, private var clave: Int)