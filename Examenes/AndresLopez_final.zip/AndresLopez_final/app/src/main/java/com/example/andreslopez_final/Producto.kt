package com.example.andreslopez_final

data class Producto(var id:Int? = null, var price: Int? = null, var stock:Int? = null,var thumbnail:String? = null,var title:String? = null) {
}