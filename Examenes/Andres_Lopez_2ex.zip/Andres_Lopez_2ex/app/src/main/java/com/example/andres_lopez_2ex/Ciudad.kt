package com.example.andres_lopez_2ex

class Ciudad(var nombre:String,var imagen:Int) {
}