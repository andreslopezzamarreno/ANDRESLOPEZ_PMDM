package com.example.andres_lopez_2ex

class Vuelo(var info:String,var imagenIda :Int, var imagenVuelta:Int,var horaIda:String,var horaVuelta:String) {
}