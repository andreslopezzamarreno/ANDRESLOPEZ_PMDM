package com.example.listas

data class Elemento(var nombre:String,var descripcion:String,var imagen:Int)