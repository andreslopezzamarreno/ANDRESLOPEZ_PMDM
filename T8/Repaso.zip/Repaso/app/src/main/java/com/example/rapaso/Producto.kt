package com.example.rapaso

data class Producto(var nombre:String,var precio: String) {
}