package com.example.rapaso

data class Usuario(var nombre:String,var pass:String,var uid:String):java.io.Serializable {
}